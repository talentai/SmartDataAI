# smartdata/__init__.py
from .modeler import SmartData
__all__ = ['SmartData']
